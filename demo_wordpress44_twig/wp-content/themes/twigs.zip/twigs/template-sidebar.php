<?php
//Template name: Sidebar
twigpress_render_twig_template();